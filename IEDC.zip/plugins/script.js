(function ($) {
    'use strict';

})(jQuery);